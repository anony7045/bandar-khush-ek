
var monkey , monkey_running;
var banana ,bananaImage, obstacle, obstacleImage;
var bananaGroup, obstacleGroup;
var score, ground;

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
createCanvas(600,600)
  monkey=createSprite(50,550,10,10)
  monkey.addAnimation("m",monkey_running);
  ground=createSprite(300,580,1200,10);
  ground.velocityX=-4;
  monkey.scale=0.2 ;
  bananaGroup= new Group();
 
}


function draw() {
background("lightblue");
if(keyDown("space")){
 monkey.velocityY=-12;
  
}
 monkey.velocityY=monkey.velocityY+1;
 if(ground.x<0){
 ground.x=ground.width/2;  
 }
 monkey.collide(ground);
  
spawnBanana();
spawnObstacles();  
drawSprites();
}
function spawnBanana(){ 
if(frameCount%80===0){
banana= createSprite(600,400,50,50);
banana.y= Math.round(random(120,200));    
banana.addImage(bananaImage);
banana.velocityX=-5; 
 banana.scale=0.2; 
bananaGroup.add(banana) ; 
banana.lifeitme=600;  
}  
}
function spawnObstacles(){
if(frameCount%300===0){
obstacle= createSprite(600,500,50,50)  ;
obstacle.y= Math.round(random(600,530)) ; 
obstacle.addImage(obstacleImage);  
obstacle.scale=0.2;  
obstacle.velocityX=-5;
obstacle.lifetime=600;  
}    
}




